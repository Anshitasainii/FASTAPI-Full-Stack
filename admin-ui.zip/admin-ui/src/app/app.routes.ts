import { Routes } from '@angular/router';
import { AdminLogin } from './pages/admin-login/admin-login';
import { AdminLayout } from './components/admin-layout/admin-layout';
import { DashboardOverview } from './pages/dashboard-overview/dashboard-overview';
import { UsersList } from './pages/users-list/users-list';
import { UserProfile } from './pages/user-profile/user-profile';
import { Settings } from './pages/settings/settings';

export const routes: Routes = [
  { path: "admin-login", component: AdminLogin },
  {
    path: "admin-dashboard",
    component: AdminLayout,
    children: [
      { path: "", component: DashboardOverview },
      { path: "users", component: UsersList },
      { path: "user/:id", component: UserProfile },
      { path: "settings", component: Settings }
    ]
  },
  { path: "admin-edit/:id", redirectTo: "admin-dashboard/user/:id", pathMatch: "full" },
  { path: "", redirectTo: "admin-login", pathMatch: "full" },
  { path: "**", redirectTo: "admin-login" }
];
