import { Component, OnInit, ChangeDetectorRef, NgZone } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [CommonModule, FormsModule, DatePipe],
  templateUrl: './user-profile.html',
  styleUrls: ['./user-profile.css']
})
export class UserProfile implements OnInit {
  user: any = null;
  isLoading = true;
  errorMessage = '';
  userId: number | null = null;
  
  showEditModal = false;
  showDeleteModal = false;
  isDeleting = false;
  editForm = {
    name: '',
    email: '',
    first_name: '',
    last_name: '',
    dob: '',
    mobile: '',
    professional_summary: '',
    gender: '',
    job_status: '',
    password: ''
  };

  constructor(
    private http: HttpClient,
    private router: Router,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone
  ) {}

  ngOnInit() {
    console.log('UserProfile ngOnInit called');
    console.log('Current route URL:', this.router.url);
    
    // Use paramMap (recommended approach)
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      console.log('Route paramMap id:', id);
      
      if (id) {
        const parsedId = parseInt(id, 10);
        if (!isNaN(parsedId) && parsedId > 0) {
          this.userId = parsedId;
          console.log('Valid User ID:', this.userId);
          this.loadUser();
        } else {
          console.error('Invalid user ID:', id);
          this.errorMessage = 'Invalid user ID';
          this.isLoading = false;
        }
      } else {
        console.error('No ID parameter found in route');
        this.errorMessage = 'User ID not found';
        this.isLoading = false;
      }
    });
  }

  loadUser() {
    if (!this.userId || isNaN(this.userId) || this.userId <= 0) {
      console.error('Invalid user ID:', this.userId);
      this.errorMessage = 'Invalid user ID';
      this.isLoading = false;
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';
    
    const apiUrl = `http://127.0.0.1:8000/${this.userId}`;
    console.log('Loading user from:', apiUrl);
    
    this.http.get(apiUrl).subscribe({
      next: (res: any) => {
        console.log('User API response:', res);
        if (res && res.error) {
          this.errorMessage = res.error;
          this.isLoading = false;
          return;
        }
        if (!res || !res.id) {
          this.errorMessage = 'User not found';
          this.isLoading = false;
          this.cdr.detectChanges();
          return;
        }
        this.ngZone.run(() => {
          this.user = { ...res }; // Create a new object reference
          console.log('User loaded successfully:', this.user);
          console.log('Setting isLoading to false');
          this.isLoading = false;
          this.errorMessage = ''; // Clear any previous errors
          this.cdr.detectChanges();
          console.log('After change detection - isLoading:', this.isLoading, 'user exists:', !!this.user);
        });
      },
      error: (err) => {
        console.error("Error loading user:", err);
        console.error("Error details:", err.error, err.status, err.statusText);
        this.ngZone.run(() => {
          this.errorMessage = err.error?.error || err.error?.message || err.message || "Failed to load user profile. Please check if the backend is running.";
          this.isLoading = false;
          this.cdr.detectChanges();
        });
      }
    });
  }

  editUser() {
    this.editForm = {
      name: this.user.name || '',
      email: this.user.email || '',
      first_name: this.user.first_name || '',
      last_name: this.user.last_name || '',
      dob: this.user.dob || '',
      mobile: this.user.mobile || '',
      professional_summary: this.user.professional_summary || '',
      gender: this.user.gender || '',
      job_status: this.user.job_status || '',
      password: ''
    };
    this.showEditModal = true;
  }

  closeEditModal() {
    this.showEditModal = false;
  }

  updateUser() {
    if (!this.userId) return;

    const updateData: any = {
      name: this.editForm.name.trim(),
      email: this.editForm.email.trim().toLowerCase(),
      first_name: this.editForm.first_name.trim() || null,
      last_name: this.editForm.last_name.trim() || null,
      mobile: this.editForm.mobile.trim() || null,
      professional_summary: this.editForm.professional_summary.trim() || null,
      gender: this.editForm.gender.trim() || null,
      job_status: this.editForm.job_status.trim() || null
    };

    if (this.editForm.dob) {
      updateData.dob = this.editForm.dob;
    }

    if (this.editForm.password.trim()) {
      updateData.password = this.editForm.password;
    }

    this.http.put(`http://127.0.0.1:8000/${this.userId}`, updateData).subscribe({
      next: (res: any) => {
        console.log("User updated:", res);
        this.closeEditModal();
        this.loadUser();
      },
      error: (err: any) => {
        console.error("Update failed:", err);
        this.errorMessage = err.error?.error || 'Failed to update user.';
      }
    });
  }

  goBack() {
    this.router.navigate(['/admin-dashboard/users']);
  }

  getInitials(name: string = '') {
    return name
      .split(' ')
      .filter(Boolean)
      .map((n) => n[0])
      .join('')
      .toUpperCase();
  }

  printPage() {
    window.print();
  }

  showDeleteConfirm() {
    this.showDeleteModal = true;
  }

  closeDeleteModal() {
    this.showDeleteModal = false;
  }

  deleteUser() {
    if (!this.userId || this.isDeleting) return;

    this.isDeleting = true;
    
    this.http.delete(`http://127.0.0.1:8000/${this.userId}`).subscribe({
      next: (res: any) => {
        console.log("User deleted:", res);
        this.ngZone.run(() => {
          this.isDeleting = false;
          this.showDeleteModal = false;
          // Navigate back to users list after successful deletion
          this.router.navigate(['/admin-dashboard/users']);
        });
      },
      error: (err: any) => {
        console.error("Delete failed:", err);
        this.ngZone.run(() => {
          this.isDeleting = false;
          this.errorMessage = err.error?.error || err.error?.message || 'Failed to delete user.';
          this.showDeleteModal = false;
          this.cdr.detectChanges();
        });
      }
    });
  }
}

