import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './settings.html',
  styleUrls: ['./settings.css']
})
export class Settings implements OnInit {
  settings = {
    name: 'Admin',
    email: 'admin@gmail.com',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
    phone: '',
    department: '',
    notifications: {
      email: true,
      push: true,
      sms: false
    }
  };

  isLoading = false;
  message = '';
  messageType: 'success' | 'error' = 'success';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    // Load admin settings from localStorage or default values
    const savedSettings = localStorage.getItem('adminSettings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        this.settings = { ...this.settings, ...parsed };
      } catch (e) {
        console.error('Error loading settings:', e);
      }
    }
  }

  updateProfile() {
    if (!this.settings.name || !this.settings.email) {
      this.showMessage('Name and email are required', 'error');
      return;
    }

    if (!this.isValidEmail(this.settings.email)) {
      this.showMessage('Please enter a valid email address', 'error');
      return;
    }

    this.isLoading = true;
    
    // Save to localStorage (in a real app, this would call an API)
    localStorage.setItem('adminSettings', JSON.stringify({
      name: this.settings.name,
      email: this.settings.email,
      phone: this.settings.phone,
      department: this.settings.department,
      notifications: this.settings.notifications
    }));

    // Simulate API call
    setTimeout(() => {
      this.isLoading = false;
      this.showMessage('Profile updated successfully!', 'success');
    }, 500);
  }

  changePassword() {
    if (!this.settings.currentPassword) {
      this.showMessage('Current password is required', 'error');
      return;
    }

    if (!this.settings.newPassword || this.settings.newPassword.length < 6) {
      this.showMessage('New password must be at least 6 characters', 'error');
      return;
    }

    if (this.settings.newPassword !== this.settings.confirmPassword) {
      this.showMessage('New passwords do not match', 'error');
      return;
    }

    // In a real app, verify current password with backend
    if (this.settings.currentPassword !== 'admin123') {
      this.showMessage('Current password is incorrect', 'error');
      return;
    }

    this.isLoading = true;

    // Simulate API call
    setTimeout(() => {
      this.isLoading = false;
      this.showMessage('Password changed successfully!', 'success');
      this.settings.currentPassword = '';
      this.settings.newPassword = '';
      this.settings.confirmPassword = '';
    }, 500);
  }

  updateNotifications() {
    localStorage.setItem('adminSettings', JSON.stringify({
      name: this.settings.name,
      email: this.settings.email,
      phone: this.settings.phone,
      department: this.settings.department,
      notifications: this.settings.notifications
    }));
    this.showMessage('Notification preferences saved!', 'success');
  }

  isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  showMessage(message: string, type: 'success' | 'error') {
    this.message = message;
    this.messageType = type;
    setTimeout(() => {
      this.message = '';
    }, 3000);
  }
}

