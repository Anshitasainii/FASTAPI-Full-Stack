import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-users-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './users-list.html',
  styleUrls: ['./users-list.css']
})
export class UsersList implements OnInit {
  users: any[] = [];
  isLoading = false;
  errorMessage = '';
  searchQuery = '';

  constructor(
    private http: HttpClient,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    if (localStorage.getItem("isAdmin") !== "true") {
      this.router.navigate(['/admin-login']);
      return;
    }
    this.loadUsers();
  }

  loadUsers() {
    this.isLoading = true;
    this.errorMessage = '';
    
    const apiUrl = "http://127.0.0.1:8000/all";
    
    this.http.get(apiUrl).subscribe({
      next: (res: any) => {
        this.isLoading = false;
        if (Array.isArray(res)) {
          this.users = [...res];
        } else {
          this.users = [];
          this.errorMessage = "Invalid response format from server";
        }
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error("Error loading users:", err);
        this.isLoading = false;
        this.users = [];
        this.errorMessage = err.error?.error || err.message || "Failed to load users.";
        this.cdr.detectChanges();
      }
    });
  }

  viewUser(user: any) {
    console.log('Navigating to user profile:', user.id);
    if (user && user.id) {
      this.router.navigate(['/admin-dashboard/user', user.id]).then(
        (success) => {
          console.log('Navigation successful:', success);
        },
        (error) => {
          console.error('Navigation error:', error);
        }
      );
    } else {
      console.error('Invalid user object:', user);
    }
  }

  getFilteredUsers() {
    if (!this.searchQuery.trim()) {
      return this.users;
    }
    const query = this.searchQuery.toLowerCase();
    return this.users.filter(u => 
      (u.name && u.name.toLowerCase().includes(query)) ||
      (u.email && u.email.toLowerCase().includes(query)) ||
      (u.first_name && u.first_name.toLowerCase().includes(query)) ||
      (u.last_name && u.last_name.toLowerCase().includes(query))
    );
  }

  trackByUserId(index: number, user: any): any {
    return user?.id || index;
  }
}

