import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'admin-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './admin-login.html',
  styleUrls: ['./admin-login.css']
})
export class AdminLogin {

  email = "";
  password = "";
  message = "";

  constructor(private http: HttpClient, private router: Router) {}

  loginAdmin() {
  this.http.post("http://127.0.0.1:8000/admin-login", {
    email: this.email,
    password: this.password
  }).subscribe({
    next: (res: any) => {
      console.log("ADMIN LOGIN SUCCESS:", res);

      localStorage.setItem("isAdmin", "true");

      this.router.navigate(['/admin-dashboard']);
    },
    error: err => {
      console.log("ADMIN LOGIN FAILED:", err);
      this.message = "Invalid credentials";
    }
  });
}

}
