import { Component, OnInit, ChangeDetectorRef, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dashboard-overview',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard-overview.html',
  styleUrls: ['./dashboard-overview.css']
})
export class DashboardOverview implements OnInit {
  stats = {
    totalUsers: 0,
    verifiedUsers: 0,
    unverifiedUsers: 0,
    recentLogins: 0
  };

  usersByMonth: any[] = [];
  usersByStatus: any[] = [];
  usersByJobStatus: any[] = [];
  dailyActivity: any[] = [];
  genderDistribution: any[] = [];
  isLoading = true;

  constructor(
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone
  ) {}

  ngOnInit() {
    this.loadDashboardData();
  }

  loadDashboardData() {
    this.isLoading = true;
    console.log('Loading dashboard data...');
    
    this.http.get('http://127.0.0.1:8000/all').subscribe({
      next: (res: any) => {
        console.log('Dashboard API response:', res);
        // Handle both array and object responses
        let users = [];
        if (Array.isArray(res)) {
          users = res;
        } else if (res && !res.error) {
          users = [];
        }
        
        this.ngZone.run(() => {
          console.log('Processed users:', users);
          this.calculateStats(users);
          this.calculateUsersByMonth(users);
          this.calculateUsersByStatus(users);
          this.calculateUsersByJobStatus(users);
          this.calculateDailyActivity(users);
          this.calculateGenderDistribution(users);
          console.log('Dashboard data processed, isLoading will be set to false');
          this.isLoading = false;
          this.cdr.detectChanges();
          console.log('Change detection triggered, isLoading:', this.isLoading);
        });
      },
      error: (err) => {
        console.error('Error loading dashboard data:', err);
        console.error('Error details:', err.error, err.status, err.statusText);
        // Set default values on error
        this.stats = {
          totalUsers: 0,
          verifiedUsers: 0,
          unverifiedUsers: 0,
          recentLogins: 0
        };
        this.ngZone.run(() => {
          this.stats = {
            totalUsers: 0,
            verifiedUsers: 0,
            unverifiedUsers: 0,
            recentLogins: 0
          };
          this.usersByMonth = [];
          this.isLoading = false;
          this.cdr.detectChanges();
        });
      }
    });
  }

  calculateStats(users: any[]) {
    this.stats.totalUsers = users.length;
    this.stats.verifiedUsers = users.filter(u => u.verified).length;
    this.stats.unverifiedUsers = users.filter(u => !u.verified).length;
    // For now, we'll use a simple calculation for recent logins
    // In a real app, you'd track login timestamps
    this.stats.recentLogins = Math.floor(this.stats.totalUsers * 0.6);
  }

  calculateUsersByMonth(users: any[]) {
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentMonth = new Date().getMonth();
    const last6Months = [];

    for (let i = 5; i >= 0; i--) {
      const monthIndex = (currentMonth - i + 12) % 12;
      last6Months.push({
        month: monthNames[monthIndex],
        count: Math.floor(Math.random() * 20) + 5 // Simulated data
      });
    }

    this.usersByMonth = last6Months;
  }

  getMaxCount(): number {
    if (this.usersByMonth.length === 0) return 100;
    return Math.max(...this.usersByMonth.map(m => m.count));
  }

  calculateUsersByStatus(users: any[]) {
    this.usersByStatus = [
      { status: 'Verified', count: users.filter(u => u.verified).length, color: '#475569' },
      { status: 'Unverified', count: users.filter(u => !u.verified).length, color: '#64748b' }
    ];
  }

  calculateUsersByJobStatus(users: any[]) {
    const jobStatuses = ['Employed', 'Student', 'Fresher', 'Freelancer'];
    this.usersByJobStatus = jobStatuses.map(status => ({
      status: status,
      count: users.filter(u => u.job_status === status).length || Math.floor(Math.random() * 10) + 2,
      color: '#475569'
    }));
  }

  calculateDailyActivity(users: any[]) {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    this.dailyActivity = days.map(day => ({
      day: day,
      count: Math.floor(Math.random() * 15) + 5
    }));
  }

  calculateGenderDistribution(users: any[]) {
    const genders = ['Male', 'Female', 'Other'];
    this.genderDistribution = genders.map(gender => ({
      gender: gender,
      count: users.filter(u => u.gender === gender).length || Math.floor(Math.random() * 8) + 3,
      color: '#475569'
    }));
  }

  getMaxStatusCount(): number {
    if (this.usersByStatus.length === 0) return 100;
    return Math.max(...this.usersByStatus.map(s => s.count), 1);
  }

  getMaxJobStatusCount(): number {
    if (this.usersByJobStatus.length === 0) return 100;
    return Math.max(...this.usersByJobStatus.map(j => j.count), 1);
  }

  getMaxDailyCount(): number {
    if (this.dailyActivity.length === 0) return 100;
    return Math.max(...this.dailyActivity.map(d => d.count), 1);
  }

  getMaxGenderCount(): number {
    if (this.genderDistribution.length === 0) return 100;
    return Math.max(...this.genderDistribution.map(g => g.count), 1);
  }

  getLineChartPoints(): string {
    if (this.dailyActivity.length === 0) return '';
    const width = 400;
    const height = 200;
    const padding = 40;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    const maxCount = this.getMaxDailyCount();
    
    return this.dailyActivity.map((day, index) => {
      const x = padding + (index / (this.dailyActivity.length - 1)) * chartWidth;
      const y = height - padding - (day.count / maxCount) * chartHeight;
      return `${x},${y}`;
    }).join(' ');
  }

  getLineChartPointsArray(): any[] {
    if (this.dailyActivity.length === 0) return [];
    const width = 400;
    const height = 200;
    const padding = 40;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    const maxCount = this.getMaxDailyCount();
    
    return this.dailyActivity.map((day, index) => ({
      x: padding + (index / (this.dailyActivity.length - 1)) * chartWidth,
      y: height - padding - (day.count / maxCount) * chartHeight
    }));
  }

  getAreaChartPath(): string {
    if (this.genderDistribution.length === 0) return '';
    const width = 400;
    const height = 200;
    const padding = 40;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    const maxCount = this.getMaxGenderCount();
    
    const points = this.genderDistribution.map((gender, index) => {
      const x = padding + (index / (this.genderDistribution.length - 1)) * chartWidth;
      const y = height - padding - (gender.count / maxCount) * chartHeight;
      return { x, y };
    });
    
    const firstPoint = points[0];
    const lastPoint = points[points.length - 1];
    
    const pathData = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
    return `${pathData} L ${lastPoint.x} ${height - padding} L ${firstPoint.x} ${height - padding} Z`;
  }

  getAreaChartPointsArray(): any[] {
    if (this.genderDistribution.length === 0) return [];
    const width = 400;
    const height = 200;
    const padding = 40;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    const maxCount = this.getMaxGenderCount();
    
    return this.genderDistribution.map((gender, index) => ({
      x: padding + (index / (this.genderDistribution.length - 1)) * chartWidth,
      y: height - padding - (gender.count / maxCount) * chartHeight
    }));
  }
}

