import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, NavigationEnd } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NgFor, NgIf, CommonModule } from '@angular/common';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'admin-dashboard',
  standalone: true,
  imports:[CommonModule, FormsModule, NgFor, NgIf],
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.css']
})
export class AdminDashboard implements OnInit {

  users: any[] = [];
  showEditModal = false;
  editingUser: any = null;
  editForm = {
    name: '',
    email: '',
    password: '',
    first_name: '',
    last_name: '',
    dob: '',
    mobile: ''
  };
  isLoading = false;
  errorMessage = '';

  constructor(
    private http: HttpClient, 
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    // Reload users when navigating back to this route
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: any) => {
        const url = event.urlAfterRedirects || event.url;
        if (url && url.includes('/admin-dashboard') && !url.includes('/admin-edit')) {
          console.log("Navigated to admin-dashboard, reloading users");
          this.loadUsers();
        }
      });
  }

  ngOnInit() {
    if (localStorage.getItem("isAdmin") !== "true") {
      this.router.navigate(['/admin-login']);
      return;
    }
    this.loadUsers();
  }

  loadUsers() {
    console.log("Loading users...");
    this.isLoading = true;
    this.errorMessage = '';
    
    // Use full URL to avoid proxy issues
    const apiUrl = "http://127.0.0.1:8000/all";
    console.log("Fetching from:", apiUrl);
    
    this.http.get(apiUrl).subscribe({
      next: (res: any) => {
        console.log("Users loaded:", res);
        console.log("Is Array?", Array.isArray(res));
        console.log("Users length:", res?.length);
        
        this.isLoading = false;
        
        if (Array.isArray(res)) {
          this.users = [...res]; // Create new array reference
          console.log("Users assigned:", this.users);
          console.log("Number of users:", this.users.length);
        } else {
          this.users = [];
          this.errorMessage = "Invalid response format from server";
          console.error("Invalid response format:", res);
        }
        
        this.cdr.detectChanges(); // Manually trigger change detection
      },
      error: (err) => {
        console.error("Error loading users:", err);
        console.error("Error details:", err.error);
        console.error("Error status:", err.status);
        console.error("Error URL:", err.url);
        
        this.isLoading = false;
        this.users = [];
        
        // Better error message handling
        let errorMsg = "Failed to load users.";
        if (err.status === 0) {
          errorMsg = "Cannot connect to backend. Please ensure the backend server is running on http://127.0.0.1:8000";
        } else if (err.status === 404) {
          errorMsg = "API endpoint not found. Please check the backend routes.";
        } else if (err.error && typeof err.error === 'string' && err.error.includes('<!doctype')) {
          errorMsg = "Backend returned HTML instead of JSON. The API endpoint may not exist or the server returned an error page.";
        } else {
          errorMsg = err.error?.error || err.error?.message || err.message || errorMsg;
        }
        
        this.errorMessage = errorMsg;
        this.cdr.detectChanges();
      }
    });
  }

  editUser(user: any) {
    this.editingUser = user;
    this.editForm = {
      name: user.name || '',
      email: user.email || '',
      password: '', // Don't prefill password for security
      first_name: user.first_name || '',
      last_name: user.last_name || '',
      dob: user.dob || '',
      mobile: user.mobile || ''
    };
    this.showEditModal = true;
    this.errorMessage = '';
  }

  closeEditModal() {
    this.showEditModal = false;
    this.editingUser = null;
    this.editForm = { 
      name: '', 
      email: '', 
      password: '',
      first_name: '',
      last_name: '',
      dob: '',
      mobile: ''
    };
    this.errorMessage = '';
  }

  updateUser() {
    if (!this.editingUser) return;

    if (!this.editForm.name.trim() || !this.editForm.email.trim()) {
      this.errorMessage = 'Name and email are required';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    const updateData: any = {
      name: this.editForm.name.trim(),
      email: this.editForm.email.trim().toLowerCase(),
      first_name: this.editForm.first_name.trim() || null,
      last_name: this.editForm.last_name.trim() || null,
      mobile: this.editForm.mobile.trim() || null
    };

    // Only include password if it's provided
    if (this.editForm.password.trim()) {
      updateData.password = this.editForm.password;
    }

    // Only include DOB if it's provided
    if (this.editForm.dob) {
      updateData.dob = this.editForm.dob;
    }

    this.http.put(`http://127.0.0.1:8000/${this.editingUser.id}`, updateData).subscribe({
      next: (res: any) => {
        console.log("User updated:", res);
        this.isLoading = false;
        this.closeEditModal();
        this.loadUsers(); // Reload the list
      },
      error: (err: any) => {
        console.error("Update failed:", err);
        this.isLoading = false;
        this.errorMessage = err.error?.error || 'Failed to update user. Please try again.';
      }
    });
  }

  deleteUserFromModal() {
    if (!this.editingUser) return;

    if (!confirm(`Are you sure you want to delete ${this.editingUser.name}? This action cannot be undone.`)) {
      return;
    }

    this.isLoading = true;
    this.http.delete(`http://127.0.0.1:8000/${this.editingUser.id}`).subscribe({
      next: () => {
        this.isLoading = false;
        this.closeEditModal();
        this.loadUsers();
      },
      error: (err: any) => {
        console.error("Delete failed:", err);
        this.isLoading = false;
        this.errorMessage = err.error?.error || 'Failed to delete user. Please try again.';
      }
    });
  }

  deleteUser(id: number, name: string) {
    if (!confirm(`Are you sure you want to delete ${name}? This action cannot be undone.`)) {
      return;
    }
    
    this.http.delete(`http://127.0.0.1:8000/${id}`).subscribe({
      next: () => {
        this.loadUsers();
      },
      error: err => {
        console.error("Delete failed:", err);
        alert("Failed to delete user. Please try again.");
      }
    });
  }

  trackByUserId(index: number, user: any): any {
    return user?.id || index;
  }
}
